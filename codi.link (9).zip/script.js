document.addEventListener("DOMContentLoaded", () => {
  const secciones = {
    menu: document.getElementById("menu"),
    pedido: document.getElementById("pedido"),
    perfil: document.getElementById("perfil"),
  };

  const listaPedido = document.getElementById("listaPedido");
  const totalTexto = document.getElementById("total");
  const pedidoActual = [];

  // Navegación entre secciones
  document.getElementById("menuBtn").addEventListener("click", () => mostrar("menu"));
  document.getElementById("pedidoBtn").addEventListener("click", () => mostrar("pedido"));
  document.getElementById("perfilBtn").addEventListener("click", () => mostrar("perfil"));

  function mostrar(seccion) {
    Object.values(secciones).forEach((s) => s.classList.remove("active"));
    secciones[seccion].classList.add("active");
  }

  // Agregar producto
  document.querySelectorAll(".add-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const producto = btn.dataset.producto;
      const precio = parseFloat(btn.dataset.precio);
      pedidoActual.push({ producto, precio });
      actualizarPedido();
    });
  });

  // Actualizar lista del pedido y total
  function actualizarPedido() {
    listaPedido.innerHTML = "";
    let total = 0;

    pedidoActual.forEach((item, index) => {
      total += item.precio;

      const li = document.createElement("li");
      li.innerHTML = `${item.producto} - $${item.precio.toFixed(2)}`;

      const eliminar = document.createElement("button");
      eliminar.textContent = "❌";
      eliminar.style.background = "none";
      eliminar.style.border = "none";
      eliminar.style.cursor = "pointer";
      eliminar.addEventListener("click", () => {
        pedidoActual.splice(index, 1);
        actualizarPedido();
      });

      li.appendChild(eliminar);
      listaPedido.appendChild(li);
    });

    totalTexto.textContent = `Total: $${total.toFixed(2)}`;
  }

  // Finalizar pedido
  document.getElementById("finalizarBtn").addEventListener("click", () => {
    if (pedidoActual.length === 0) {
      alert("Tu pedido está vacío 🍟");
      return;
    }
    alert("¡Pedido completado! 🎉 Total pagado: " + totalTexto.textContent);
    pedidoActual.length = 0;
    actualizarPedido();
    mostrar("menu");
  });
});

